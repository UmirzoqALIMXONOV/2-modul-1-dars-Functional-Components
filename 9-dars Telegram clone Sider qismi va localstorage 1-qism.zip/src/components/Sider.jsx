import React, { Component } from 'react'

export default class Sider extends Component {

    render() {
        const { AddUser, users } = this.props
        return (
            <div className='row my-3'>
                <div className="col-md-12">
                    <button className='btn btn-outline-dark px-5 '
                             onClick={AddUser}>add</button>
                    <hr />
                    <ul  className='list-group'>
                        {
                            users.map((item, index)=>
                             <li key={index} className='list-group-item'>{item.firstName+" "+item.lastName} </li>)
                        }
                    </ul>
                </div>
            </div>
        )
    }
}
