import React, { Component } from 'react'
import ModalComponent from './ModalComponent'

const Style = {
    cursor: "pointer"
}

export default class App extends Component {

    state = {
        tasks: [
            { id: 1, title: "task1", status: 'open' },
            { id: 2, title: "task2", status: 'pending' },
            { id: 3, title: "task3", status: 'inprog' },
            { id: 4, title: "task4", status: 'complete' },
            { id: 5, title: "task5", status: 'open' },
            { id: 6, title: "task6", status: 'open' },
            { id: 7, title: "task7", status: 'pending' },
            { id: 8, title: "task8", status: 'pending' }
        ],
        modalVisible: false,
        pushTask: '',
        active: false
    }
    OpenModal = (item) => {
        this.setState({
            modalVisible: !this.state.modalVisible,
            pushTask: item
        })
    }

    SaveEdit = (title, status) => {
        const { pushTask, tasks } = this.state
        tasks.map((item, index) => {
            if (item.id === pushTask.id) {
                item.title = title
                item.status = status
            }
        })
        this.setState({
            tasks,
            modalVisible: false
        })
    }

    AddTask = () => {
        this.setState({
            active: !this.state.active
        })
    }


    TaskAdd = (title, status) => {
        const { tasks } = this.state
        var obj = {
            id: this.state.tasks.length + 1,
            title: title,
            status: status
        }
        tasks.push(obj)
        this.setState({
            tasks,
            active: false
        })

    }
    render() {
        const { modalVisible, pushTask, active } = this.state
        return (
            <div className='container-fluid'>
                <ModalComponent
                    isOpen={modalVisible}
                    toggle={this.OpenModal}
                    SaveEdit={this.SaveEdit}
                    pushTask={pushTask}
                    active={active}
                    AddTask={this.AddTask}
                    TaskAdd={this.TaskAdd}
                />
                <div className="row">
                    <div className="col-md-3 border bg-info p-3">
                        <h2 className='text-center my-3'>Open</h2>
                        {
                            this.state.tasks.filter(item => item.status === "open")
                                .map((item, index) =>
                                    <div onClick={() => this.OpenModal(item)} style={Style} key={index} className="d-flex justify-content-between my-2 bg-light p-2">
                                        <h4>{item.title}</h4>
                                        <button className='btn btn-danger btn-sm'>delete</button>
                                    </div>)
                        }
                        <div className="d-grid">
                            <button className='btn btn-dark' onClick={this.AddTask}>add task</button>
                        </div>
                    </div>
                    <div className="col-md-3 border bg-info p-3">
                        <h2 className='text-center my-3'>Pending</h2>
                        {
                            this.state.tasks.filter(item => item.status === "pending")
                                .map((item, index) =>
                                    <div onClick={() => this.OpenModal(item)} style={Style} key={index} className="d-flex justify-content-between my-2 bg-light p-2">
                                        <h4>{item.title}</h4>
                                        <button className='btn btn-danger btn-sm'>delete</button>
                                    </div>)
                        }
                        <div className="d-grid">
                            <button className='btn btn-dark' onClick={this.AddTask}>add task</button>
                        </div>
                    </div>
                    <div className="col-md-3 border bg-info p-3">
                        <h2 className='text-center my-3'>Inprog</h2>
                        {
                            this.state.tasks.filter(item => item.status === "inprog")
                                .map((item, index) =>
                                    <div onClick={() => this.OpenModal(item)} style={Style} key={index} className="d-flex justify-content-between my-2 bg-light p-2">
                                        <h4>{item.title}</h4>
                                        <button className='btn btn-danger btn-sm'>delete</button>
                                    </div>)
                        }
                        <div className="d-grid">
                            <button className='btn btn-dark' onClick={this.AddTask}>add task</button>
                        </div>
                    </div>
                    <div className="col-md-3 border bg-info p-3">
                        <h2 className='text-center my-3'>Complete</h2>
                        {
                            this.state.tasks.filter(item => item.status === "complete")
                                .map((item, index) =>
                                    <div onClick={() => this.OpenModal(item)} style={Style} key={index} className="d-flex justify-content-between my-2 bg-light p-2">
                                        <h4>{item.title}</h4>
                                        <button className='btn btn-danger btn-sm'>delete</button>
                                    </div>
                                )
                        }
                        <div className="d-grid">
                            <button className='btn btn-dark' onClick={this.AddTask}>add task</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
