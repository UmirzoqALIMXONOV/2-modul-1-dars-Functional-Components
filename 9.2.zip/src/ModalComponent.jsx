import React, { Component } from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from 'reactstrap'

export default class ModalComponent extends Component {


    SubmitTasks = (event) => {
        event.preventDefault()
        var title = event.target[0].value
        var status = event.target[1].value
        this.props.SaveEdit(title, status)
     
    }

    AddSubmit=(event)=>{
        event.preventDefault()
        var title = event.target[0].value
        var status = event.target[1].value
        this.props.TaskAdd(title, status)
        
    }
    render() {
        const { isOpen, toggle,  active, AddTask } = this.props
        return (
            <div>

                {/*  For Add */}
                <Modal isOpen={active} toggle={AddTask}>
                    <ModalHeader>ADD TASK</ModalHeader>
                    <ModalBody>
                        <form id='aa' onSubmit={this.AddSubmit} >
                            <select className='form-control'>
                            <option value="task1">task1</option>
                                <option value="task2">task2</option>
                                <option value="task3">task3</option>
                                <option value="task4">task4</option>
                                <option value="task5">task5</option>
                                <option value="task6">task6</option>
                                <option value="task7">task7</option>
                                <option value="task8">task8 </option>
                            </select>
                            <select className='form-control my-3'>
                                <option value="open">open</option>
                                <option value="pending">pending</option>
                                <option value="inprog">inprog</option>
                                <option value="complete">complete</option>
                            </select>

                        </form>
                    </ModalBody>
                    <ModalFooter>
                        <Button color='success' form='aa' >save</Button>
                        <Button color='danger' onClick={AddTask}>cencel</Button>
                    </ModalFooter>
                </Modal>

                {/* For Edit */}
                <Modal isOpen={isOpen} toggle={toggle}>
                    <ModalHeader>choose</ModalHeader>
                    <ModalBody>
                        <form id='aa' onSubmit={this.SubmitTasks} >
                            <select className='form-control'>
                                <option value="task1">task1</option>
                                <option value="task2">task2</option>
                                <option value="task3">task3</option>
                                <option value="task4">task4</option>
                                <option value="task5">task5</option>
                                <option value="task6">task6</option>
                                <option value="task7">task7</option>
                                <option value="task8">task8 </option>
                            </select>
                            <select className='form-control my-3'>
                                <option value="open">open</option>
                                <option value="pending">pending</option>
                                <option value="inprog">inprog</option>
                                <option value="complete">complete</option>
                            </select>

                        </form>
                    </ModalBody>
                    <ModalFooter>
                        <Button color='warning' form='aa' >edit</Button>
                        <Button color='danger' onClick={toggle}>cencel</Button>
                    </ModalFooter>
                </Modal>
            </div>
        )
    }
}
