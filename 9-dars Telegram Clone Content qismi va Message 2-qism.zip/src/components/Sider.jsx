import React, { Component } from 'react'

export default class Sider extends Component {
    SelectUser=(item)=>{
       this.props.UserSelect(item)
    }
    render() {
        const { AddUser, users, selectedUser } = this.props
        return (
            <div className='row my-3'>
                <div className="col-md-12">
                    <button className='btn btn-outline-dark px-5 '
                             onClick={AddUser}>add</button>
                    <hr />
                    <ul  className='list-group'>
                        {
                            users.map((item, index)=>
                             <li onClick={()=>this.SelectUser(item)} key={index} className={`list-group-item ${selectedUser.firstName===item.firstName? 'active':''} `}>{item.firstName+" "+item.lastName} </li>)
                        }
                    </ul>
                </div>
            </div>
        )
    }
}
