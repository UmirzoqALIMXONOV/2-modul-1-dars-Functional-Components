import React, { Component, useRef } from 'react'

export default class Content extends Component {
  state = {
    message: [],
    xabar: ''
  }
  SubmitMessage = (event) => {
    this.setState({
      xabar: event.target.value
    })
  }


  PushMessage = () => {
    const { xabar, message } = this.state
    var obj = {
      id: this.state.message.length + 1,
      message: xabar,
      date: new Date().getHours() + ":" + new Date().getMinutes()
    }
    message.push(obj)
    this.setState({
      message,
      xabar: ''
    })
    localStorage.setItem("msg", JSON.stringify(message))
  }




  componentDidMount() {
    var mgsString = localStorage.getItem("msg")
    if (mgsString) {
      var msgArray = JSON.parse(mgsString)
      this.setState({
        message: msgArray
      })
    }

  }

  render() {
    const { selectedUser } = this.props
    return (
      <div>
        <div className="header">
          <h3 className='m-0 p-3'>
            {selectedUser ?
              selectedUser.firstName + " " + selectedUser.lastName + " " + selectedUser.phone
              : ''}
          </h3>
        </div>
        <div className="message">
          {
            this.state.message.map((item, index) =>
              <div key={index} className='msg'>
                <span>{item.message}</span> <span>{item.date}</span>
              </div>)
          }
        </div>
        <div className="write d-flex">
          <input value={this.state.xabar} onChange={this.SubmitMessage} type="text" style={{ width: "920px" }} placeholder='whire any message!' className='form-control' />
          <button className='btn btn-success mx-2' onClick={this.PushMessage}>send</button>
        </div>
      </div>
    )
  }
}
