import { AvForm, AvField } from 'availity-reactstrap-validation'
import React, { Component } from 'react'
import { Modal, ModalBody, ModalFooter, ModalHeader, Button} from 'reactstrap'

export default class ModalComponent extends Component {


    SubmitForm=(event, values)=>{
        this.props.saveSabmit(values)
    }



  render() {
    const {modalVisible, AddUser} = this.props
    return (
      <div>
        <Modal isOpen={modalVisible} toggle={AddUser}>
            <ModalHeader>add user</ModalHeader>
            <ModalBody> 
                <AvForm id="aa" onValidSubmit={this.SubmitForm}>
                    <AvField name="firstName" type="text" label="FirstName" required/>
                    <AvField name="lastName" type="text" label="LastName" required/>
                    <AvField name="phone" type="number" label="Phone" required/>
                </AvForm>
            </ModalBody>
            <ModalFooter>
                <Button form='aa' color='success'>save</Button>
                <Button color='danger' onClick={AddUser}>cencel</Button>
            </ModalFooter>
        </Modal>
      </div>
    )
  }
}
