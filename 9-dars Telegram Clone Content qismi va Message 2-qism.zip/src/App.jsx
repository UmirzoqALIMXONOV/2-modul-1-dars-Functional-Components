import React, { Component } from 'react'
import Sider from './components/Sider'
import Content from './components/Content'
import ModalComponent from './components/ModalComponent'

export default class App extends Component {

  state = {
    modalVisible: false,
    users: [],
    selectedUser:''
  }

  AddUser = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }
  saveSabmit = (values) => {
    const { users } = this.state
    users.push(values)
    this.setState({
      users: users,
      modalVisible: false,
    })
    localStorage.setItem("users", JSON.stringify(users))
  }


  UserSelect=(item)=>{
    this.setState({
      selectedUser:item
    })
    localStorage.setItem("userSelect", JSON.stringify(this.state.selectedUser))
  }

  componentDidMount(){
    var usersString = localStorage.getItem("users")
    if(usersString){
      var userArray =  JSON.parse(usersString)
      this.setState({
       users:userArray
      })
    }

    var selectUserString = localStorage.getItem("userSelect")
    if(selectUserString){
      var selectUserObj = JSON.parse(selectUserString)
      this.setState({
        selectedUser:selectUserObj
      })
    }

  }
  
  render() {
    return (
      <div className='container-fluid'>
        <div className="row">
          <div className="col-md-3 sider-parent">
            <Sider AddUser={this.AddUser} users={this.state.users}  UserSelect={this.UserSelect} selectedUser={this.state.selectedUser}/>
          </div>
          <div className="col-md-9 content-parent">
            <Content selectedUser={this.state.selectedUser} />
          </div>
        </div>
        <ModalComponent
          modalVisible={this.state.modalVisible}
          AddUser={this.AddUser}
          saveSabmit={this.saveSabmit} />
      </div>
    )
  }
}
