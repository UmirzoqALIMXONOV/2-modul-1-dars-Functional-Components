import React, { useState } from 'react'
import { connect } from 'react-redux'
import PageModal from '../Modals/PageModal'

const Xodimlar = ({ xodim, addXodim, EditXodim, Delete, Search, qidir }) => {

  const [modalVisible, setModalVisible] = useState(false)
  const [modalVisibleEdit, setModalVisibleEdit] = useState(false)

  const OpenModal=()=>{
    setModalVisible(prev=>!prev)
  }

  const SaveXodim=(values)=>{
    addXodim(values)
    setModalVisible(false)
  }

  const Edits=(item)=>{
    EditXodim(item)
    setModalVisibleEdit(prev=>!prev)
  }

  const EditModal=()=>{
    setModalVisibleEdit(prev=>!prev)
  }
  const Deletes=(index)=>{
    Delete(index)
  }

  const Searchs=(event)=>{
    Search(event.target.value)
  }
  return (
    <>
    <div className="row my-5">
      <div className="col-md-3">
        <input onChange={Searchs} type="search" className='form-control' placeholder='Search...' />
      </div>
      <div className="col-md-5">
        <h2 className='text-center'>Xodimlar</h2>
      </div>
      <div className="col-md-4">
        <button className='btn btn-outline-dark px-3 float-end'onClick={OpenModal}>+Add</button>
      </div>
    </div>
      <div className='row my-3'>
        <div className="col-md-12">
          <table className='table table-dark'>
            <thead>
              <tr>
                <th>N0</th>
                <th>Ismi</th>
                <th>Familiyasi</th>
                <th>Telefon</th>
                <th>Lavozimi</th>
                <th>Ilmiy darajasi</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {
                xodim.filter((item,index)=>{
                  if(qidir===""){
                    return item
                  }else if(item.name.toUpperCase().includes(qidir.toUpperCase())){
                    return item
                  }
                })
                .map((item, index) => <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{item.name}</td>
                  <td>{item.familiya}</td>
                  <td>{item.phone}</td>
                  <td>{item.lavozimi_id}</td>
                  <td>{item.ilmiy_daraja_id}</td>
                  <td>
                    <button className='btn btn-warning btn-sm mx-2' onClick={()=>Edits(item)}>edit</button>
                    <button className='btn btn-danger btn-sm mx-2' onClick={()=>Deletes(index)}>del</button>
                  </td>
                </tr>)
              }
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Page */}

      <PageModal 
        isOpen={modalVisible} 
        toggle={OpenModal} 
        save={SaveXodim}
        isOpen2={modalVisibleEdit}
        toggle2={EditModal}
      />


    </>
  )
}
function mapStateToProps(state) {
  return {
    xodim: state.XodimlarReducer.Xodimlar,
    qidir:state.XodimlarReducer.qidir
  }
}


function mapDispatchToProps(dispatch){
  return {
      addXodim:(values)=>{
        dispatch({
          type:"ADD_XODIM",
          name:values.name,
          firstName:values.firstName,
          phone:values.phone,
          select:values.select,
          select2:values.select2
        })
      },
      EditXodim:(item)=>{
        dispatch({
          type:"EDIT",
          edit:item
        })
      },
      Delete:(index)=>{
        dispatch({
          type:"Delete",
          id:index
        })
      },
      Search:(value)=>{
        dispatch({
          type:"search",
          value:value
        })
      }
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Xodimlar)