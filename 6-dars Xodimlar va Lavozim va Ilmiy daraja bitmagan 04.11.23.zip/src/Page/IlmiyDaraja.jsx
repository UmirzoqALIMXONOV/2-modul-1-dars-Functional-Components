import React from 'react'
import { useState } from 'react'
import { connect } from 'react-redux'
import IlmiyModal from '../Modals/IlmiyModal'

const IlmiyDaraja = ({ ilmiydaraja, AddIlmiyDaraja }) => {

    const [modalVisible, setModalVisible] = useState(false)

    const OpenModal=()=>{
        setModalVisible(prev=>!prev)
    }

    const saveSubmit=(values)=>{
        AddIlmiyDaraja(values)
    }
    return (
        <>
            <div className="row">
                <div className="col-md-8 offset-2">
                    <div className='row my-4'>
                        <div className="col-md-3 ">
                            <input type="search" className='form-control' placeholder='Search...' />
                        </div>
                        <div className="col-md-6">
                            <h2 className='text-center text-secondary'>Ilmiy Daraja</h2>
                        </div>
                        <div className="col-md-3">
                            <button className='btn btn-outline-secondary float-end' onClick={OpenModal}>+Add</button>
                        </div>
                    </div>
                    <div className="row my-4">
                        <div className="col-md-12">
                            <table className='table table-secondary table-hover table-striped'>
                                <thead>
                                    <tr>
                                        <th>N0</th>
                                        <th>Nomi</th>
                                        <th>Bonus</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        ilmiydaraja.map((item, index) =>
                                            <tr key={index}>
                                                <td>{index + 1}</td>
                                                <td>{item.nomi}</td>
                                                <td>{item.bonus}</td>
                                                <td>
                                                    <button className='btn btn-warning btn-sm mx-2'>edit</button>
                                                    <button className='btn btn-danger btn-sm mx-2'>del</button>
                                                </td>
                                            </tr>)
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {/* Modal Ilmiy daraja */}
            <IlmiyModal isOpen={modalVisible} toggle={OpenModal} save={saveSubmit}/>


        </>
    )
}
function mapStateToProps(state) {
    console.log(state)
    return {
        ilmiydaraja: state.IlmiyDarajaReducer.IlmiyDaraja
    }
}
function mapDIspatchToProps(dispatch) {
    return {
        AddIlmiyDaraja:(values)=>{
            dispatch({
                type:"addIlmiyDaraja",
                nomi:values.nomi,
                bonus:values.bonus
            })
        }
    }

}
export default connect(mapStateToProps, mapDIspatchToProps)(IlmiyDaraja)