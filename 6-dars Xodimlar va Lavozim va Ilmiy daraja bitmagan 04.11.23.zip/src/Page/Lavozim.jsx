import React, { useState } from 'react'
import { connect } from 'react-redux'
import LavozimModal from '../Modals/LavozimModal'

const Lavozim = ({ lavozim, addLavozim, EditLavozim, LavozimDel, Qidir, qidir }) => {

    const [modalVisible, setModalVisible] = useState(false)
    const [modalVisibleEdit, setModalVisibleEdit] = useState(false)

    const OpenModal = () => {
        setModalVisible(prev => !prev)
    }

    const Edits = (item) => {
        EditLavozim(item)
        setModalVisibleEdit(prev => !prev)
    }

    const EditModal = () => {
        setModalVisibleEdit(prev => !prev)
    }
    const SaveLavozim = (values) => {
        addLavozim(values)
        setModalVisible(false)
    }
    const DelLav = (index) => {
        LavozimDel(index)
    }
    const Search=(event)=>{
        Qidir(event.target.value)
    }
    return (
        <>
            <div className='col-md-8 offset-2'>
                <div className="row my-5">
                    <div className="col-md-3">
                        <input type="search" onChange={Search} className='form-control' placeholder='Search...' />
                    </div>
                    <div className="col-md-5">
                        <h2 className='text-center'>Lavozimlar</h2>
                    </div>
                    <div className="col-md-4">
                        <button className='btn btn-outline-success px-3 float-end' onClick={OpenModal}>+Add</button>
                    </div>
                </div>
                <table className='table table-success table-striped table-sm table-hover'>
                    <thead>
                        <tr>
                            <th>N0</th>
                            <th>Nomi</th>
                            <th>Maosh</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            lavozim.filter((item, index)=>{
                                if(qidir===''){
                                    return item
                                }else if(item.nomi.toLowerCase().includes(qidir.toLowerCase())){
                                    return item
                                }
                            }).map((item, index) =>
                                <tr key={index+1}>
                                    <td>{item.id}</td>
                                    <td>{item.nomi}</td>
                                    <td>{item.maosh}</td>
                                    <td>
                                        <button className='btn btn-warning btn-sm' onClick={() => Edits(item)}>edit</button>
                                        <button className='btn btn-danger mx-2 btn-sm' onClick={()=>DelLav(index)}>del</button>
                                    </td>
                                </tr>)
                        }
                    </tbody>
                </table>
            </div>

            {/* Lavozim Modal */}

            <LavozimModal
                isOpen={modalVisible}
                toggle={OpenModal}
                save={SaveLavozim}
                isOpen2={modalVisibleEdit}
                toggle2={EditModal}
            />


        </>
    )
}
function mapStateToProps(state) {
    return {
        lavozim: state.LavozimReducer.Lavozim,
        qidir:state.LavozimReducer.qidir
    }
}
function mapDispatchToProps(dispatch) {
    return {
        addLavozim: (values) => {
            dispatch({
                type: "addLavozim",
                nomi: values.nomi,
                maosh: values.maosh
            })
        },
        EditLavozim: (item) => {
            dispatch({
                type: "Edit",
                edit: item
            })
        },
        LavozimDel: (index) => {
            dispatch({
                type:"delLavozim",
                payload:index
            })
        },
        Qidir:(value)=>{
            dispatch({
                type:"qidir",
                payload:value
            })
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Lavozim)