import React from 'react'
import Xodimlar from './Page/Xodimlar'
import Lavozim from './Page/Lavozim'
import { Link } from 'react-router-dom'
import { Route, Switch } from 'react-router-dom/cjs/react-router-dom.min'
import IlmiyDaraja from './Page/IlmiyDaraja'

const App = () => {
  return (
    <div className='container'>
      <div className="row my-3">
        <div className="col-6 offset-3">
        <Link to='/xodimlar'><button className='btn btn-dark mx-4'>Xodimlar</button></Link>
        <Link to='/lavozimlar'><button className='btn btn-success mx-4'>Lavozimlar</button></Link>
        <Link to='/ilmiydaraja'><button className='btn btn-secondary mx-4'>Ilmiy Daraja</button></Link>
        </div>
      </div>
      <hr />
      <Switch>
        <Route path='/xodimlar' component={Xodimlar}/>
        <Route path='/lavozimlar' component={Lavozim}/>
        <Route path='/ilmiydaraja' component={IlmiyDaraja}/>
      </Switch>
    </div>
  )
}

export default App