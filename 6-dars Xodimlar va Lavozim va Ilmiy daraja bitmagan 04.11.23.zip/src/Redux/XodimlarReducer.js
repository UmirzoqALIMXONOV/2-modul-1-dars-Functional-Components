function XodimlarReducer(state = {
    Xodimlar: [
        {
            id: 1,
            name: "John",
            familiya: "Doe",
            phone: 2222,
            lavozimi_id: 'frontend',
            ilmiy_daraja_id: "Senior"
        },
        {
            id: 2,
            name: "Jane",
            familiya: "Smith",
            phone: 3333,
            lavozimi_id: 'Designer',
            ilmiy_daraja_id: "Middle"
        },
        {
            id: 3,
            name: "Umirzoq",
            familiya: "Alimxonov",
            phone: 1111,
            lavozimi_id: 'FullStack',
            ilmiy_daraja_id: "Senior"
        },

    ],
    qidir: '',
    data: ''
}, action) {
    switch (action.type) {
        case "ADD_XODIM":
            const arr = [...state.Xodimlar]
            arr.push({
                id: state.Xodimlar.length + 1,
                name: action.name,
                familiya: action.firstName,
                phone: action.phone,
                lavozimi_id: action.select,
                ilmiy_daraja_id: action.select2
            })
            return { ...state, Xodimlar: [...arr] }
            break
        case "EDIT":
            state = { ...state, data: action.edit }
            break
        case "SaveEdit":
            const a = state.Xodimlar.map((item) => {
                var b = state.data
                if (item.id === b.id) {
                    item = {
                        ...item,
                        name: action.value.name,
                        familiya: action.value.firstName,
                        phone: action.value.phone,
                        lavozimi_id: action.value.select,
                        ilmiy_daraja_id: action.value.select2
                    }
                }
                return item
            })
            state = {
                ...state,
                Xodimlar: a
            }
            break
        case "Delete":
            var D = [...state.Xodimlar]
            D.splice(action.id, 1)
            state = {
                ...state,
                Xodimlar: D
            }
            break
        case "search":
            state = {
                ...state,
                qidir: action.value
            }
            break
        
    }
    return state
}
export default XodimlarReducer