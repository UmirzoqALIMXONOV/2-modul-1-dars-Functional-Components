function IlmiyDarajaReducer(state = {
    IlmiyDaraja: [
        { nomi: "Junior", bonus: 10 },
        { nomi: "Middle", bonus: 20 },
        { nomi: "Senior", bonus: 30 }
    ]
}, action) {
    switch (action.type) {
        case "addIlmiyDaraja":
            const ilm = [...state.IlmiyDaraja]
            ilm.push({
                id: state.IlmiyDaraja.length + 1,
                nomi: action.nomi,
                bonus: action.bonus,
            })
            return { ...state, IlmiyDaraja: [...ilm] }
            break
    }
    return state
}
export default IlmiyDarajaReducer