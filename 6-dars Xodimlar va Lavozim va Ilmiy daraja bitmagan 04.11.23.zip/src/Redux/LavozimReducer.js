function LavozimReducer(state = {
    Lavozim: [
        { id: 1, nomi: "Frontend", maosh: "2000$" },
        { id: 2, nomi: "Backend", maosh: "3000$" },
        { id: 3, nomi: "Designer", maosh: "1200$" }
    ],
    data: '',
    qidir:''

}, action) {
    switch (action.type) {
        case "addLavozim":
            const lav = [...state.Lavozim]
            lav.push({
                id: state.Lavozim.length + 1,
                nomi: action.nomi,
                maosh: action.maosh,
            })
            return { ...state, Lavozim: [...lav] }
            break
        case "Edit":
            state = { ...state, data: action.edit }
            break
        case "SaveEdit":
            const a = state.Lavozim.map((item) => {
                var b = state.data
                if (item.id === b.id) {
                    item = {
                        ...item,
                        nomi: action.values.nomi,
                        maosh: action.values.maosh,
                    }
                }
                return item
            })
            state = {
                ...state,
                Lavozim: a
            }
            break
        case "delLavozim":
            var D = [...state.Lavozim]
            D.splice(action.payload, 1)
            state = {
                ...state,
                Lavozim: D
            }
            break
        case "qidir":
            state = {
                ...state,
                qidir: action.payload
            }
    }
    return state
}

export default LavozimReducer