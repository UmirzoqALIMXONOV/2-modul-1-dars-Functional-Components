import { applyMiddleware, combineReducers } from "redux";
import { createStore } from "redux";
import logger from "redux-logger";
import XodimlarReducer from "./XodimlarReducer";
import LavozimReducer from "./LavozimReducer";
import IlmiyDarajaReducer from "./IlmiyDarajaReducer";

export const store = createStore(combineReducers({
    XodimlarReducer,
    LavozimReducer,
    IlmiyDarajaReducer
    
}), applyMiddleware(logger))