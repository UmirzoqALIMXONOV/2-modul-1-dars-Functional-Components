import { AvField, AvForm } from 'availity-reactstrap-validation'
import React from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from 'reactstrap'

const IlmiyModal = ({ isOpen, toggle, save }) => {

    const AddSubmit=(event, values)=>{
        save(values)
        toggle()
    }
    return (
        <div>
            <Modal isOpen={isOpen} toggle={toggle}>
                <ModalHeader>ilmiy daraja qo'shish</ModalHeader>
                <ModalBody>
                    <AvForm id='form' onValidSubmit={AddSubmit} >
                        <AvField name="nomi" label="Nomi" required />
                        <AvField name="bonus" label="Bonus" required />
                    </AvForm>
                </ModalBody>
                <ModalFooter>
                    <Button form='form' color='success'>save</Button>
                    <Button color='danger' onClick={toggle}>cencel</Button>
                </ModalFooter>
            </Modal>
        </div>
    )
}

export default IlmiyModal