import { AvForm, AvField } from 'availity-reactstrap-validation'
import React from 'react'
import { connect } from 'react-redux'
import { Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap'

const PageModal = ({isOpen, toggle, save, isOpen2, toggle2, SaveEdit}) => {


    const AddSubmit=(event, values)=>{
        save(values)
    }

    const EditSubmit=(event, values)=>{
        SaveEdit(values)
        toggle2()
    }
    return (
        <div>
            {/*  ADD XODIM */}
            <Modal isOpen={isOpen} toggle={toggle}>
                <ModalHeader> Xodim Qo'shish </ModalHeader>
                <ModalBody>
                    <AvForm id='form' onValidSubmit={AddSubmit}>
                        <AvField name="name" label="Name" required />
                        <AvField name="firstName" label="Familiya" required />
                        <AvField name="phone" label="Phone" type={'number'} required />
                        <AvField name="select" label="Lavozim" type={'select'} required>
                            <option>Frontend</option>
                            <option>Backend</option>
                            <option>Designer</option>
                        </AvField>
                        <AvField name="select2" label="IlmiyDarajasi" type={'select'} required>
                            <option>Junior</option>
                            <option>Middle</option>
                            <option>Senior</option>
                        </AvField>
                    </AvForm>
                </ModalBody>
                <ModalFooter>
                    <button form='form' className='btn btn-success mx-2 btn-sm'>saqlash</button>
                    <button className='btn btn-danger mx-2 btn-sm' onClick={toggle}>chiqish</button>
                </ModalFooter>
            </Modal>

              {/*  EDIT XODIM */}
              <Modal  isOpen={isOpen2} toggle={toggle2} >
                <ModalHeader> Edit Xodim</ModalHeader>
                <ModalBody>
                    <AvForm id='form2' onValidSubmit={EditSubmit}>
                        <AvField name="name" label="Name" required />
                        <AvField name="firstName" label="Familiya" required />
                        <AvField name="phone" label="Phone" type={'number'} required />
                        <AvField name="select" label="Lavozim" type={'select'} required>
                            <option>Frontend</option>
                            <option>Backend</option>
                            <option>Designer</option>
                        </AvField>
                        <AvField name="select2" label="IlmiyDarajasi" type={'select'} required>
                            <option>Junior</option>
                            <option>Middle</option>
                            <option>Senior</option>
                        </AvField>
                    </AvForm>
                </ModalBody>
                <ModalFooter>
                    <button form='form2' className='btn btn-success mx-2 btn-sm'>saqlash</button>
                    <button className='btn btn-danger mx-2 btn-sm' onClick={toggle2} >chiqish</button>
                </ModalFooter>
            </Modal>
        </div>
    )
}
function mapDispatchToProps(dispatch){
    return {
        SaveEdit:(values)=>{
            dispatch({
                type:"SaveEdit",
                value:values
            })
        }
    }
}
export default connect( null, mapDispatchToProps)(PageModal) 