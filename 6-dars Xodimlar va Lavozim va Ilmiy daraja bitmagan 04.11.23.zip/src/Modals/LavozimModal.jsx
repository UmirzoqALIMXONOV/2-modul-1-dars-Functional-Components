import React from 'react'
import { Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap'
import { AvForm, AvField } from 'availity-reactstrap-validation'
import { connect } from 'react-redux'

const LavozimModal = ({isOpen, toggle, save, isOpen2, toggle2, SaveEdit}) => {

    const AddSubmit=(event, values)=>{
        save(values)
    }


    const EditSubmit=(event, values)=>{
        SaveEdit(values)
        toggle2()
    }
  return (
    <div>
         {/* Open Modal */}
          <Modal isOpen={isOpen} toggle={toggle}>
                <ModalHeader> Xodim Qo'shish </ModalHeader>
                <ModalBody>
                    <AvForm id='form' onValidSubmit={AddSubmit} >
                        <AvField name="nomi" label="Nomi" required />
                        <AvField name="maosh" label="Maosh" required />
                    </AvForm>
                </ModalBody>
                <ModalFooter>
                    <button form='form' className='btn btn-success mx-2 btn-sm'>saqlash</button>
                    <button className='btn btn-danger mx-2 btn-sm'onClick={toggle}>chiqish</button>
                </ModalFooter>
            </Modal>


        {/* Edit Modal */}
          <Modal isOpen={isOpen2} toggle={toggle2}>
                <ModalHeader> Xodim Qo'shish </ModalHeader>
                <ModalBody>
                    <AvForm id='form2' onValidSubmit={EditSubmit} >
                        <AvField name="nomi" label="Nomi" required />
                        <AvField name="maosh" label="Maosh" required />
                    </AvForm>
                </ModalBody>
                <ModalFooter>
                    <button form='form2' className='btn btn-success mx-2 btn-sm'>saqlash</button>
                    <button className='btn btn-danger mx-2 btn-sm'onClick={toggle2}>chiqish</button>
                </ModalFooter>
            </Modal>

    </div>
  )
}
function mapStateToProps(state){
    return {

    }
}

function mapDispatchToProps(dispatch){
    return {
        SaveEdit:(values)=>{
            dispatch({
                type:"SaveEdit",
                values:values
            })
        }
    }
}

export default  connect(mapStateToProps, mapDispatchToProps)(LavozimModal)